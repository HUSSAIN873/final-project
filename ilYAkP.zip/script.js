let cart=[];
function money(n){return "$"+n.toFixed(2)}
function add(name,price){
  let item=cart.find(x=>x.name===name);
  if(item)item.qty++; else cart.push({name,price,qty:1});
  renderCart(); notify(name+" added to your cart.");
}
function renderCart(){
  const count=cart.reduce((a,x)=>a+x.qty,0);
  document.getElementById("bagCount").textContent=count;
  const list=document.getElementById("cartList");
  if(!cart.length){list.innerHTML='<div class="cart-empty"><i class="bi bi-bag"></i>Your cart is empty.</div>';document.getElementById("total").textContent="$0.00";return}
  list.innerHTML=cart.map((x,i)=>`<div class="cart-row"><div><h6>${x.name}</h6><small>${money(x.price)} × ${x.qty}</small></div><div class="text-end"><b>${money(x.price*x.qty)}</b><br><button class="cart-remove" onclick="removeCart(${i})"><i class="bi bi-trash3"></i></button></div></div>`).join("");
  document.getElementById("total").textContent=money(cart.reduce((a,x)=>a+x.price*x.qty,0));
}
function removeCart(i){cart.splice(i,1);renderCart()}
function openCart(){bootstrap.Offcanvas.getOrCreateInstance(document.getElementById("cartDrawer")).show()}
function wish(btn){btn.classList.toggle("liked");btn.innerHTML=btn.classList.contains("liked")?'<i class="bi bi-heart-fill"></i>':'<i class="bi bi-heart"></i>'}
function filterShop(cat,button){
  document.querySelectorAll(".chip").forEach(x=>x.classList.remove("active"));
  if(button)button.classList.add("active");
  let shown=0;
  document.querySelectorAll(".item").forEach(card=>{
    const ok=cat==="All"||card.dataset.cat===cat;
    card.style.display=ok?"block":"none";if(ok)shown++;
  });
  document.getElementById("empty").classList.toggle("d-none",shown!==0);
}
function setCategory(cat){
  filterShop(cat);
  document.getElementById("shop").scrollIntoView({behavior:"smooth"});
}
function searchProducts(value){
  const q=value.toLowerCase().trim();let shown=0;
  document.querySelectorAll(".item").forEach(card=>{
    const ok=card.dataset.name.toLowerCase().includes(q)||card.dataset.cat.toLowerCase().includes(q);
    card.style.display=ok?"block":"none";if(ok)shown++;
  });
  document.getElementById("empty").classList.toggle("d-none",shown!==0);
}
document.getElementById("modalSearch").addEventListener("input",e=>searchProducts(e.target.value));
document.getElementById("contactForm").addEventListener("submit",e=>{
  e.preventDefault();document.getElementById("contactMsg").textContent="Thanks! Your message has been received.";e.target.reset();
});
function checkout(){if(!cart.length){notify("Your cart is empty.");return}notify("Checkout demo — your order is ready.")}
function notify(msg){document.getElementById("toastText").textContent=msg;bootstrap.Toast.getOrCreateInstance(document.getElementById("toast"),{delay:2200}).show()}
let remaining=8*3600+42*60+19;
setInterval(()=>{remaining--;if(remaining<0)remaining=8*3600+42*60+19;let h=Math.floor(remaining/3600),m=Math.floor((remaining%3600)/60),s=remaining%60;document.getElementById("hours").textContent=String(h).padStart(2,"0");document.getElementById("mins").textContent=String(m).padStart(2,"0");document.getElementById("secs").textContent=String(s).padStart(2,"0")},1000);
renderCart();
